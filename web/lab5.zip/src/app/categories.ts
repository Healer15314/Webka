export interface Category {
  id: number;
  name: string;
  
}

export const categories = [
  {
    id: 1,
    name: 'Sport'
  },
    {
      id:2,
      name:'Phone'
    },
    {
      id:3,
      name:'usb'
    },
    {
      id:4,
      name:'beauty'
    }
];